from __future__ import annotations

import csv
import hashlib
import importlib.metadata
import io
import json
import os
import platform
import re
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import yaml
from jsonschema import Draft202012Validator


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2).encode('utf-8')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, content):
    if isinstance(content, str):
        content = content.encode('utf-8')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('wb') as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    if digest(path.read_bytes()) != digest(content):
        raise IOError(f'Escritura incompleta: {path.name}')


def save_json(path, data):
    save(path, encode(data))


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def save_csv(path, rows, fields):
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    save(path, stream.getvalue())


def unique_map(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f'Clave duplicada: {key!r}')
        obj[key] = value
    return obj


class CloudFormationLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        return unique_map(self.construct_pairs(node, deep=deep))


CloudFormationLoader.yaml_implicit_resolvers = {
    key: [(tag, pattern) for tag, pattern in pairs if tag != 'tag:yaml.org,2002:timestamp']
    for key, pairs in yaml.SafeLoader.yaml_implicit_resolvers.items()
}


def intrinsic(loader, suffix, node):
    name = suffix if suffix in {'Ref', 'Condition'} else 'Fn::' + suffix
    if isinstance(node, yaml.ScalarNode):
        value = loader.construct_scalar(node)
        if name == 'Fn::GetAtt':
            value = value.split('.', 1)
    elif isinstance(node, yaml.SequenceNode):
        value = loader.construct_sequence(node, deep=True)
    else:
        value = loader.construct_mapping(node, deep=True)
    return {name: value}


CloudFormationLoader.add_multi_constructor('!', intrinsic)


def walk(data, pointer=''):
    yield pointer, data
    if isinstance(data, dict):
        for key, value in data.items():
            if not isinstance(key, str):
                raise ValueError('Se esperaba una clave de texto en CloudFormation')
            escaped = key.replace('~', '~0').replace('/', '~1')
            yield from walk(value, pointer + '/' + escaped)
    if isinstance(data, list):
        for index, value in enumerate(data):
            yield from walk(value, pointer + '/' + str(index))


def normalize(raw, suffix, context):
    if suffix == '.json':
        data = json.loads(raw, object_pairs_hook=unique_map)
    elif suffix in {'.yaml', '.yml'}:
        data = yaml.load(raw, Loader=CloudFormationLoader)
    else:
        raise ValueError(f'Formato no admitido: {suffix}')
    if not isinstance(data, dict) or not isinstance(data.get('Resources'), dict):
        raise ValueError('La plantilla debe contener el objeto Resources')
    resources = data['Resources']
    if not 1 <= len(resources) <= 12:
        raise ValueError('El protocolo admite entre 1 y 12 recursos por plantilla')
    params = data.get('Parameters', {})
    bound = {name: prop['Default'] for name, prop in params.items() if 'Default' in prop}
    bound.update(context.get('parametros', {}))
    unresolved = []
    for pointer, value in walk(data):
        tag = pointer.rsplit('/', 1)[-1]
        if tag == 'Ref' and isinstance(value, str) and value not in resources and value not in bound:
            unresolved.append({'ruta': pointer, 'referencia': value})
        if tag == 'Fn::ImportValue' or (isinstance(value, str) and '{{resolve:' in value):
            unresolved.append({'ruta': pointer, 'referencia': 'valor externo'})
    normalized = []
    queries = {}
    for name, res in resources.items():
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9]*', name) or not isinstance(res.get('Type'), str):
            raise ValueError(f'Recurso sin ID lógico o tipo válido: {name}')
        normalized.append(dict(res, LogicalId=name))
        properties = res.get('Properties', {})
        keys = queries.setdefault(res['Type'], set())
        keys.update(properties)
        keys.update(k for k in ('Condition', 'DependsOn') if k in res)
    return {
        'documento': data, 'recursos': normalized, 'parametros_efectivos': bound,
        'referencias_sin_resolver': unresolved,
        'consultas': [f'{name} CloudFormation security configuration ' + ' '.join(sorted(keys))
                      for name, keys in sorted(queries.items())],
    }


def object_schema(fields):
    return {'type': 'object', 'properties': fields, 'required': list(fields), 'additionalProperties': False}


STRING = {'type': 'string'}
STRINGS = {'type': 'array', 'items': STRING}
DETECTOR = object_schema({'hallazgos': {'type': 'array', 'items': object_schema({
    'recurso_logico_id': STRING, 'control_id': STRING,
    'estado': {'type': 'string', 'enum': ['alerta', 'abstencion']},
    'rutas_evidencia': STRINGS, 'fragmento_ids': STRINGS, 'justificacion': STRING,
    'recomendacion': STRING,
})}})
REPORT = object_schema({'items': {'type': 'array', 'items': object_schema({
    'hallazgo_id': STRING, 'prioridad': {'type': 'string', 'enum': ['alta', 'media', 'baja', 'revision']},
    'impacto': STRING, 'accion': STRING,
})}})


class Bedrock:
    transient = {'ThrottlingException', 'ModelNotReadyException', 'ServiceUnavailableException',
                 'ModelTimeoutException', 'InternalServerException', 'TooManyRequestsException',
                 'ReadTimeoutError', 'ConnectTimeoutError', 'EndpointConnectionError', 'ConnectionClosedError'}

    def __init__(self, config, token=None):
        import boto3
        from botocore.config import Config

        if token:
            os.environ['AWS_BEARER_TOKEN_BEDROCK'] = token
        self.config = config
        self.client = boto3.client('bedrock-runtime', region_name=config['region'], config=Config(
            retries={'total_max_attempts': 1}, connect_timeout=10, read_timeout=150))

    def request(self, stage, ledger, model, invoke):
        for attempt in range(1, 4):
            start = utc()
            timer = time.perf_counter()
            try:
                payload, usage, request_id = invoke()
            except Exception as exc:
                error = getattr(exc, 'response', {}).get('Error', {}).get('Code', type(exc).__name__)
                retry = error in self.transient and attempt < 3
                ledger({'etapa': stage, 'modelo': model, 'inicio': start, 'intento': attempt,
                        'segundos': time.perf_counter() - timer, 'error': error,
                        'espera_siguiente_s': 2 ** (attempt-1) if retry else 0})
                if not retry:
                    raise RuntimeError(f'Bedrock {stage}: {error}') from None
                time.sleep(2 ** (attempt-1))
                continue
            ledger({'etapa': stage, 'modelo': model, 'inicio': start, 'intento': attempt,
                    'segundos': time.perf_counter() - timer, 'uso': usage, 'request_id': request_id})
            return payload

    def embed(self, text, ledger, stage):
        model = self.config['embedding_model']

        def invoke():
            response = self.client.invoke_model(modelId=model, contentType='application/json',
                                                accept='application/json', body=json.dumps({
                'inputText': text, 'dimensions': self.config['dimensions'], 'normalize': True,
            }))
            body = json.loads(response['body'].read())
            return body['embedding'], {'inputTokens': body.get('inputTextTokenCount', 0)}, response.get('ResponseMetadata', {}).get('RequestId')

        return self.request(stage, ledger, model, invoke)

    def generate(self, prompt, payload, schema, stage, ledger):
        model = self.config['text_model']

        def invoke():
            response = self.client.converse(modelId=model, system=[{'text': prompt}],
                messages=[{'role': 'user', 'content': [{'text': encode(payload).decode('utf-8')}]}],
                inferenceConfig={'temperature': self.config['temperature'], 'maxTokens': self.config[stage + '_max_tokens']},
                outputConfig={'textFormat': {'type': 'json_schema', 'structure': {'jsonSchema': {
                    'name': stage, 'schema': json.dumps(schema, sort_keys=True),
                }}}})
            message = response.get('output', {}).get('message', {})
            content = ''.join(part.get('text', '') for part in message.get('content', []))
            return {'texto': content, 'stop_reason': response.get('stopReason')}, response.get('usage', {}), response.get('ResponseMetadata', {}).get('RequestId')

        return self.request(stage, ledger, model, invoke)


def append_event(path, item):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(item, ensure_ascii=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def load_config(root):
    return yaml.safe_load((root / 'config/config.yaml').read_text(encoding='utf-8'))


def config_for_suite(root, suite):
    config = load_config(root)
    catalog = yaml.safe_load((root / 'config/controles.yaml').read_text(encoding='utf-8'))
    return config, {key: catalog[key] for key in config['controles_por_fase'][suite]}


def docs_for_version(root, version):
    folder = root / 'docs' / version
    manifest = read_csv(folder / 'docs_manifest.csv')
    records = []
    for source in manifest:
        text = (folder / source['archivo']).read_bytes()
        if source['sha256'] != digest(text):
            raise ValueError(f'Documento modificado: {source["archivo"]}')
        for number, body in enumerate(re.split(r'(?m)^## ', text.decode('utf-8'))):
            title, _, excerpt = body.partition('\n')
            excerpt = excerpt.strip()
            if not excerpt:
                continue
            if len(excerpt) > 1800:
                slices = [excerpt[i:i+1800] for i in range(0, len(excerpt)-200, 1600)]
            else:
                slices = [excerpt]
            for idx, fragment in enumerate(slices, 1):
                chunk_id = f'{source["doc_id"]}-{number}-{idx}'
                records.append({'fragmento_id': chunk_id, 'seccion': title, 'texto': fragment,
                                'url': source['url'], 'sha256': source['sha256'], 'fecha': source['fecha_consulta']})
    if not records or len({row['fragmento_id'] for row in records}) != len(records):
        raise ValueError('El índice requiere fragmentos con IDs únicos')
    return records


def vector(value, dimensions):
    values = np.asarray(value, dtype=np.float32)
    if values.shape != (dimensions,) or not np.isfinite(values).all():
        raise ValueError('Embedding con formato incorrecto')
    norm = np.linalg.norm(values)
    if norm <= 0:
        raise ValueError('Embedding sin magnitud')
    return values / norm


def load_index(root, version, model):
    config = model.config
    records = docs_for_version(root, version)
    identity = {'fragmentos': records, 'modelo': config['embedding_model'], 'dimensions': config['dimensions'],
                'region': config['region'], 'backend': type(model).__name__, 'formato': 1}
    key = digest(encode(identity))
    folder = root / 'indices' / key
    file = folder / 'indice.npz'
    meta = folder / 'estado.json'
    if (file.exists() and meta.exists() and read_json(meta).get('sha256') == digest(file.read_bytes())):
        with np.load(file, allow_pickle=False) as index:
            matrix = index['vectors']
        if matrix.shape == (len(records), config['dimensions']):
            return key, records, matrix, read_json(meta)['segundos']
    start = time.perf_counter()
    ledger = lambda row: append_event(folder / 'calls.jsonl', row)
    pieces = []
    for item in records:
        cache_key = digest(encode([type(model).__name__, config['region'], config['embedding_model'], config['dimensions'],
                                   item['seccion'], item['texto']]))
        cache = root / 'indices' / 'cache' / f'{cache_key}.json'
        if cache.exists():
            values = vector(read_json(cache), config['dimensions'])
        else:
            values = vector(model.embed(item['seccion'] + '\n' + item['texto'], ledger, 'indexacion'), config['dimensions'])
            save_json(cache, values.tolist())
        pieces.append(values)
    matrix = np.stack(pieces)
    stream = io.BytesIO()
    np.savez_compressed(stream, vectors=matrix)
    save(file, stream.getvalue())
    save(folder / 'fragmentos.jsonl', ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in records))
    elapsed = time.perf_counter() - start
    save_json(meta, {'sha256': digest(file.read_bytes()), 'segundos': elapsed, 'version_docs': version,
                     'fragmentos': len(records), 'backend': type(model).__name__})
    return key, records, matrix, elapsed


def retrieve(normalized, model, records, matrix, ledger):
    ranks = []
    for query in normalized['consultas']:
        embedding = vector(model.embed(query, ledger, 'recuperacion'), model.config['dimensions'])
        scores = matrix @ embedding
        ranked = sorted(range(len(records)), key=lambda i: (-float(scores[i]), records[i]['fragmento_id']))
        ranks.append([dict(records[i], similitud=float(scores[i]), consulta=query, ranking=rank)
                      for rank, i in enumerate(ranked[:model.config['top_k']], 1)])
    selected = {}
    for position in range(model.config['top_k']):
        for ranking in ranks:
            if position < len(ranking) and len(selected) < model.config['max_fragmentos']:
                item = ranking[position]
                selected.setdefault(item['fragmento_id'], item)
    return {'ranking_por_consulta': ranks, 'fragmentos': list(selected.values())}


def parse_response(raw, schema):
    if raw['stop_reason'] != 'end_turn':
        raise ValueError(f'Respuesta incompleta: {raw["stop_reason"]}')
    parsed = json.loads(raw['texto'], object_pairs_hook=unique_map)
    Draft202012Validator(schema).validate(parsed)
    return parsed


def findings(case_id, response, normalized, passages):
    parsed = parse_response(response, DETECTOR)
    available = set(item['fragmento_id'] for item in passages)
    paths = {path for path, _ in walk(normalized['documento'])}
    return [dict(item, hallazgo_id=f'H{number:03d}', plantilla_id=case_id,
                 fragmentos_invalidos=[ref for ref in item['fragmento_ids'] if ref not in available],
                 rutas_invalidas=[route for route in item['rutas_evidencia'] if route not in paths])
            for number, item in enumerate(parsed['hallazgos'], 1)]


def render_report(case_id, alerts, raw, passages):
    issues = parse_response(raw, REPORT)['items']
    by_id = unique_map((row['hallazgo_id'], row) for row in issues)
    required = {item['hallazgo_id'] for item in alerts}
    if required != set(by_id):
        raise ValueError('El informe debe conservar todos los IDs del detector')
    sources = {item['fragmento_id']: item for item in passages}
    lines = [f'# Informe de la plantilla {case_id}', '']
    if not alerts:
        lines.append('El detector no emitió alertas ni abstenciones para los controles evaluados.')
    priority = {'alta': 0, 'media': 1, 'baja': 2, 'revision': 3}
    for finding in sorted(alerts, key=lambda item: priority[by_id[item['hallazgo_id']]['prioridad']]):
        issue = by_id[finding['hallazgo_id']]
        lines.extend([f'## {finding["hallazgo_id"]} · {finding["control_id"]}', '',
            f'**Recurso** `{finding["recurso_logico_id"]}`', '',
            f'**Estado** {finding["estado"]} · **Prioridad** {issue["prioridad"]}', '',
            finding['justificacion'], '', '**Evidencia en IaC** '+ ', '.join(f'`{p}`' for p in finding['rutas_evidencia']), '',
            '**Impacto** ' + issue['impacto'], '', '**Acción sugerida** ' + issue['accion'], ''])
        for reference in dict.fromkeys(finding['fragmento_ids']):
            if reference in sources:
                source = sources[reference]
                lines.append(f'- [{reference} · {source["seccion"]}]({source["url"]})')
        if finding['fragmentos_invalidos'] or finding['rutas_invalidas']:
            lines.append('- Revisar la evidencia. El detector citó referencias que el notebook no pudo verificar.')
        lines.append('')
    return '\n'.join(lines).rstrip() + '\n'


def suite_cases(root, suite):
    manifest = read_csv(root / 'corpus' / suite / 'manifiesto_corpus.csv')
    for row in manifest:
        if not re.fullmatch('[A-Z][0-9]{2}', row['plantilla_id']):
            raise ValueError('ID de plantilla inválido')
        for field, hash_field in [('archivo', 'sha256'), ('contexto', 'contexto_sha256')]:
            path = root / 'corpus' / suite / row[field]
            if path.parent != root / 'corpus' / suite or digest(path.read_bytes()) != row[hash_field]:
                raise ValueError(f'Entrada modificada: {path.name}. Crear una nueva versión del corpus.')
    if len({row['plantilla_id'] for row in manifest}) != len(manifest):
        raise ValueError('La fase contiene IDs repetidos')
    return manifest


def study_identity(root, suite):
    sources = ['pipeline.py', 'config/config.yaml', 'config/controles.yaml', 'config/detector.txt',
               'config/informe.txt', 'requirements.txt', f'corpus/{suite}/manifiesto_corpus.csv']
    return {name: digest((root / name).read_bytes()) for name in sources}


def review_formal(root, reference, confirmed=False):
    if not confirmed:
        raise ValueError('El especialista debe confirmar explícitamente que revisó y aprobó la referencia.')
    cases = {row['plantilla_id']: row for row in suite_cases(root, 'formal')}
    _, catalog = config_for_suite(root, 'formal')
    ref = read_csv(reference)
    keys = [(row['plantilla_id'], row['recurso_logico_id'], row['control_id']) for row in ref]
    if len(keys) != len(set(keys)):
        raise ValueError('Claves repetidas en la referencia formal')
    by_case = {case_id: [] for case_id in cases}
    for row in ref:
        if row['control_id'] not in catalog or row['estado'] not in {'incumple', 'cumple', 'indeterminado'}:
            raise ValueError('La referencia contiene un control o estado no reconocido')
        if any(not row[field].strip() for field in ('revisor', 'fecha_revision', 'justificacion', 'fuente_control', 'rutas_evidencia')):
            raise ValueError('Faltan evidencias o datos de revisión en la referencia')
        datetime.strptime(row['fecha_revision'], '%Y-%m-%d')
        by_case[row['plantilla_id']].append(row)
    defects = []
    for case_id, case in cases.items():
        folder = root / 'corpus/formal'
        template = folder / case['archivo']
        context = read_json(folder / case['contexto'])
        normalized = normalize(template.read_text(encoding='utf-8'), template.suffix, context)
        paths = {path for path, _ in walk(normalized['documento'])}
        for row in by_case[case_id]:
            resource = normalized['documento']['Resources'].get(row['recurso_logico_id'])
            if resource is None or resource['Type'] != row['tipo_recurso'] or row['contexto_id'] != context['contexto_id']:
                raise ValueError(f'Recurso, tipo o contexto inválido en {case_id}')
            if not set(json.loads(row['rutas_evidencia'])) <= paths:
                raise ValueError(f'Rutas de evidencia inválidas en {case_id}')
        if not by_case[case_id] or all(row['estado'] == 'indeterminado' for row in by_case[case_id]):
            raise ValueError(f'Faltan controles evaluables en {case_id}')
        defects.append(sum(row['estado'] == 'incumple' for row in by_case[case_id]))
    if sorted(defects) != [0, 0, 0, 0, 0, 3, 4, 4, 4, 5]:
        raise ValueError(f'Distribución de fallos incompatible: {defects}')
    save_json(root / 'config/formal_lock.json', {'referencia_sha256': digest(reference.read_bytes()),
              'entradas': study_identity(root, 'formal'), 'documentos_sha256': digest(encode(docs_for_version(root, 'base'))),
              'fecha_cierre': utc(), 'plantillas': len(cases), 'incumplimientos': sum(defects)})


def execute(root, suite, run_id, version, model, simulation=False):
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}', run_id):
        raise ValueError('Nombre de corrida inválido')
    if simulation != isinstance(model, Simulation):
        raise ValueError('El indicador de simulación debe coincidir con el modelo usado')
    config, catalog = config_for_suite(root, suite)
    cases = suite_cases(root, suite)
    identity = study_identity(root, suite)
    reference_hash = None
    if suite == 'formal' and not simulation:
        lock_path = root / 'config/formal_lock.json'
        if not lock_path.exists():
            raise ValueError('La evaluación formal requiere primero el cierre de referencia por el especialista.')
        lock = read_json(lock_path)
        if lock['entradas'] != identity or lock['documentos_sha256'] != digest(encode(docs_for_version(root, version))):
            raise ValueError('La configuración formal cambió desde que se cerró la referencia.')
        reference_hash = lock['referencia_sha256']
    key, records, matrix, index_seconds = load_index(root, version, model)
    run = root / 'runs' / run_id
    sheet = {'fase': suite, 'version_docs': version, 'identidad': identity, 'indice': key,
             'referencia_sha256': reference_hash, 'config': config, 'simulacion': simulation,
             'python': platform.python_version(), 'dependencias': {
                 name: importlib.metadata.version(name) for name in ('numpy', 'PyYAML', 'jsonschema')},
             'casos': [case['plantilla_id'] for case in cases]}
    if not simulation:
        sheet['dependencias'].update({name: importlib.metadata.version(name) for name in ('boto3', 'botocore')})
    signature = digest(encode(sheet))
    manifest_path = run / 'manifiesto.json'
    if manifest_path.exists():
        if read_json(manifest_path)['sha256'] != signature:
            raise ValueError('La configuración cambió. Elegir otro ID de corrida.')
    else:
        save_json(manifest_path, dict(sheet, sha256=signature, inicio=utc(), indexacion_s=index_seconds))
        for label in ('config.yaml', 'controles.yaml', 'detector.txt', 'informe.txt'):
            save(run / 'config' / label, (root / 'config' / label).read_bytes())
    detector_prompt = (root / 'config/detector.txt').read_text(encoding='utf-8')
    report_prompt = (root / 'config/informe.txt').read_text(encoding='utf-8')
    progress = []
    for case in cases:
        case_id = case['plantilla_id']
        folder = run / case_id
        state_path = folder / 'estado.json'
        prior = read_json(state_path) if state_path.exists() else {'etapas': {}}
        state = prior['etapas']
        resumed = bool(state) and 'informe' not in state
        if resumed:
            prior['reanudada'] = True
        ledger = lambda event: append_event(folder / 'calls.jsonl', event)

        def stage(name, files, work):
            previous = state.get(name, {})
            if set(previous.get('archivos', {})) == set(files) and all(
                (folder / filename).exists() and digest((folder / filename).read_bytes()) == previous['archivos'][filename]
                for filename in files
            ):
                return previous['segundos']
            start = time.perf_counter()
            order = ('normalizacion', 'recuperacion', 'detector', 'informe')
            for invalidated in order[order.index(name):]:
                state.pop(invalidated, None)
            result = work()
            compute_seconds = time.perf_counter() - start
            hashes = {}
            for filename, output in result.items():
                save(folder / filename, output if isinstance(output, str) else encode(output))
                hashes[filename] = digest((folder / filename).read_bytes())
            if set(hashes) != set(files):
                raise ValueError(f'Artefactos incompletos en {name}')
            state[name] = {'segundos': compute_seconds, 'escritura_s': time.perf_counter() - start - compute_seconds,
                           'archivos': hashes, 'fin': utc()}
            save_json(state_path, prior)
            return compute_seconds

        sequence = 'normalizacion'
        try:
            source = root / 'corpus' / suite / case['archivo']
            context = read_json(root / 'corpus' / suite / case['contexto'])

            def normalize_case():
                raw = source.read_text(encoding='utf-8')
                return {'normalizado.json': normalize(raw, source.suffix, context), 'plantilla_original.txt': raw,
                        'contexto.json': context}

            stage(sequence, ['normalizado.json', 'plantilla_original.txt', 'contexto.json'], normalize_case)
            norm = read_json(folder / 'normalizado.json')
            sequence = 'recuperacion'
            stage(sequence, ['recuperacion.json'], lambda: {'recuperacion.json': retrieve(norm, model, records, matrix, ledger)})
            passages = read_json(folder / 'recuperacion.json')['fragmentos']
            sequence = 'detector'

            def detect_case():
                data = {'plantilla_original': (folder / 'plantilla_original.txt').read_text(encoding='utf-8'),
                        'resumen': {k: v for k, v in norm.items() if k not in {'documento', 'consultas'}},
                        'contexto': context, 'controles': {key: value['regla'] for key, value in catalog.items()},
                        'fragmentos': passages}
                response = model.generate(detector_prompt, data, DETECTOR, 'detector', ledger)
                try:
                    alerts = findings(case_id, response, norm, passages)
                except Exception:
                    save_json(folder / 'detector_rechazado.json', response)
                    raise
                return {'respuesta_detector.json': response, 'hallazgos.json': alerts}

            stage(sequence, ['respuesta_detector.json', 'hallazgos.json'], detect_case)
            alerts = read_json(folder / 'hallazgos.json')
            sequence = 'informe'

            def report_case():
                cited = {ref for finding in alerts for ref in finding['fragmento_ids']}
                response = model.generate(report_prompt, {'hallazgos': alerts,
                    'fragmentos': [item for item in passages if item['fragmento_id'] in cited]}, REPORT, 'informe', ledger)
                try:
                    report = render_report(case_id, alerts, response, passages)
                except Exception:
                    save_json(folder / 'informe_rechazado.json', response)
                    raise
                return {'respuesta_informe.json': response, 'informe.md': report}

            stage(sequence, ['respuesta_informe.json', 'informe.md'], report_case)
        except Exception as exc:
            prior['error'] = {'etapa': sequence, 'tipo': type(exc).__name__, 'detalle': str(exc)[:240], 'hora': utc()}
            save_json(state_path, prior)
        else:
            if prior.pop('error', None):
                save_json(state_path, prior)
        progress.append({'plantilla_id': case_id, 'estado': 'incompleta' if 'error' in prior else 'completa',
                         'error': prior.get('error')})
    save_json(run / 'progreso.json', progress)
    return run, progress


KEY = ('plantilla_id', 'recurso_logico_id', 'control_id')


def match(alerts, reference, catalog):
    def key(row):
        return tuple(row[field] for field in KEY)

    truth = unique_map((key(row), row['estado']) for row in reference)
    positives = {item for item, status in truth.items() if status == 'incumple'}
    counts = dict.fromkeys(('TP', 'FP', 'FN', 'duplicado', 'abstencion', 'indeterminado', 'fuera_catalogo', 'cita_invalida', 'ruta_invalida'), 0)
    linked = []
    seen = set()
    for alert in alerts:
        item = key(alert)
        if alert['estado'] == 'abstencion':
            outcome = 'abstencion'
        elif item in seen:
            outcome = 'duplicado'
        elif alert['control_id'] not in catalog:
            outcome = 'fuera_catalogo'
        elif truth.get(item) == 'indeterminado':
            outcome = 'indeterminado'
        else:
            outcome = 'TP' if item in positives else 'FP'
        if alert['estado'] == 'alerta':
            seen.add(item)
        counts[outcome] += 1
        counts['cita_invalida'] += bool(alert.get('fragmentos_invalidos'))
        counts['ruta_invalida'] += bool(alert.get('rutas_invalidas'))
        linked.append(dict(zip(KEY, item), hallazgo_id=alert['hallazgo_id'], resultado=outcome))
    for item in sorted(positives - seen):
        counts['FN'] += 1
        linked.append(dict(zip(KEY, item), hallazgo_id='', resultado='FN'))
    return counts, linked


def scores(counts):
    tp, fp, fn = (counts[key] for key in ('TP', 'FP', 'FN'))
    fraction = lambda a, b: a / b if b else None
    return {'precision': fraction(tp, tp + fp), 'recall': fraction(tp, tp + fn),
            'f1': fraction(2*tp, 2*tp + fp + fn), 'fraccion_alertas_incorrectas': fraction(fp, tp + fp)}


def display_score(value):
    return f'{value:.3f}' if value is not None else 'N/A'


def evaluate(root, run, reference):
    meta = read_json(run / 'manifiesto.json')
    progress = read_json(run / 'progreso.json')
    if meta['referencia_sha256'] and digest(reference.read_bytes()) != meta['referencia_sha256']:
        raise ValueError('La referencia no coincide con el hash registrado al cerrar el corpus.')
    ref = read_csv(reference)
    known_cases = {row['plantilla_id'] for row in ref}
    if known_cases != set(meta['casos']):
        raise ValueError('Los casos de la referencia no coinciden con la corrida.')
    all_controls = yaml.safe_load((run / 'config/controles.yaml').read_text(encoding='utf-8'))
    controls = {key: all_controls[key] for key in meta['config']['controles_por_fase'][meta['fase']]}
    table = []
    matching = []
    aggregate = {}
    remediation = []
    for case in progress:
        case_id = case['plantilla_id']
        folder = run / case_id
        if case['estado'] != 'completa':
            table.append(dict(case))
            continue
        timer = time.perf_counter()
        state = read_json(folder / 'estado.json')
        for stage in state['etapas'].values():
            for filename, expected in stage['archivos'].items():
                if digest((folder / filename).read_bytes()) != expected:
                    raise ValueError(f'Archivo de corrida alterado: {case_id}/{filename}')
        ref_rows = [row for row in ref if row['plantilla_id'] == case_id]
        alerts = read_json(folder / 'hallazgos.json')
        counts, matches = match(alerts, ref_rows, controls)
        matching.extend(matches)
        for key, value in counts.items():
            aggregate[key] = aggregate.get(key, 0) + value
        values = scores(counts)
        historical = {key: value if counts['TP'] + counts['FN'] else None for key, value in values.items()
                      if key in {'precision', 'recall', 'f1'}}
        lines = ['## Evaluación', '', f'**TP** {counts["TP"]} · **FP** {counts["FP"]} · **FN** {counts["FN"]}', '',
                 f'**Precisión** {display_score(values["precision"])} · **Recall** {display_score(values["recall"])} · **F1** {display_score(values["f1"])}', '']
        if meta['simulacion']:
            lines.insert(0, '**Simulación local. Métricas de prueba del flujo.**\n')
        save(folder / 'informe_puntuado.md', (folder / 'informe.md').read_text(encoding='utf-8') + '\n' + '\n'.join(lines))
        elapsed = time.perf_counter() - timer
        times = {name: stage['segundos'] for name, stage in state['etapas'].items()}
        write_time = sum(stage['escritura_s'] for stage in state['etapas'].values())
        table.append(dict(case, **counts, **values, vista_tabla_1=historical, reanudada=state.get('reanudada', False),
            tiempos_s=dict(times, escritura=write_time, evaluacion=elapsed,
                           total_comparable=sum(times[name] for name in ('recuperacion', 'detector', 'informe')),
                           total_activo=sum(times.values()) + write_time + elapsed)))
        report_items = parse_response(read_json(folder / 'respuesta_informe.json'), REPORT)['items']
        remediation.extend({'plantilla_id': case_id, 'hallazgo_id': row['hallazgo_id'], 'accion': row['accion']}
                           for row in report_items)
    count_ok = sum(row['estado'] == 'completa' for row in table)
    time_stats = {}
    if count_ok:
        labels = next(row['tiempos_s'] for row in table if 'tiempos_s' in row)
        for label in labels:
            series = [row['tiempos_s'][label] for row in table if 'tiempos_s' in row]
            time_stats[label] = {'media': statistics.mean(series), 'mediana': statistics.median(series),
                                 'min': min(series), 'max': max(series)}
    metrics = {'fase': meta['fase'], 'simulacion': meta['simulacion'], 'completas': count_ok,
               'programadas': len(table), 'por_plantilla': table, 'latencia_s': time_stats,
               'micro': dict(aggregate, **scores(aggregate)) if aggregate else None}
    save_json(run / 'metricas.json', metrics)
    save_csv(run / 'emparejamientos.csv', matching, [*KEY, 'hallazgo_id', 'resultado'])
    rubric = run / 'remediacion.csv'
    if not rubric.exists():
        save_csv(rubric, remediation, ['plantilla_id', 'hallazgo_id', 'accion', 'correccion', 'especificidad',
            'respaldo', 'contexto', 'sobre_remediacion', 'cita_incorrecta', 'propiedad_obsoleta', 'comentario', 'revisor'])
    return metrics


class Simulation:
    """Backend local para comprobar artefactos. No evalúa la calidad de un LLM."""

    def __init__(self, config):
        self.config = config

    def embed(self, text, ledger, stage):
        values = np.zeros(self.config['dimensions'], dtype=np.float32)
        for term in re.findall(r'[\w:.-]+', text.lower()):
            values[int(digest(term.encode())[:8], 16) % len(values)] += 1
        ledger({'etapa': stage, 'simulacion': True})
        return values

    def generate(self, prompt, payload, schema, stage, ledger):
        ledger({'etapa': stage, 'simulacion': True})
        if stage == 'informe':
            result = {'items': [{'hallazgo_id': row['hallazgo_id'], 'prioridad': 'revision',
                                 'impacto': 'Ejemplo de impacto para la prueba del flujo.', 'accion': row['recomendacion']}
                                for row in payload['hallazgos']]}
        else:
            result = {'hallazgos': []}
            raw = payload['plantilla_original']
            document = json.loads(raw) if raw.lstrip().startswith('{') else yaml.load(raw, Loader=CloudFormationLoader)
            resources = document['Resources']
            if 'SG-SSH-22' in payload['controles'] and len(payload['controles']) == 1:
                for name, entry in resources.items():
                    if entry['Type'] != 'AWS::EC2::SecurityGroup':
                        continue
                    for position, rule in enumerate(entry.get('Properties', {}).get('SecurityGroupIngress', [])):
                        routes = [f'/Resources/{name}/Properties/SecurityGroupIngress/{position}']
                        sources = [rule.get('CidrIp'), rule.get('CidrIpv6')]
                        ref = rule.get('SourcePrefixListId', {}).get('Ref') if isinstance(rule.get('SourcePrefixListId'), dict) else None
                        if ref in resources:
                            sources.extend(item['Cidr'] for item in resources[ref]['Properties']['Entries'])
                            routes.append(f'/Resources/{ref}/Properties/Entries')
                        includes_ssh = str(rule.get('IpProtocol')) == '-1' or (str(rule.get('IpProtocol')) in {'tcp', '6'}
                            and isinstance(rule.get('FromPort'), int) and rule['FromPort'] <= 22 <= rule['ToPort'])
                        if includes_ssh and {'0.0.0.0/0', '::/0'}.intersection(sources):
                            result['hallazgos'].append({'recurso_logico_id': name, 'control_id': 'SG-SSH-22', 'estado': 'alerta',
                                'rutas_evidencia': routes, 'fragmento_ids': [p['fragmento_id'] for p in payload['fragmentos'] if p['fragmento_id'].startswith('EC2-')][:1],
                                'justificacion': 'La regla permite SSH desde un origen irrestricto.',
                                'recomendacion': 'Eliminar la regla si SSH no es necesario o limitarla al origen administrativo autorizado.'})
            if 'SEC-ROTACION' in payload['controles'] and document.get('Transform') == 'AWS::SecretsManager-2020-07-23':
                citations = [p['fragmento_id'] for p in payload['fragmentos'] if p['fragmento_id'].startswith('AVISO-')]
                for name, entry in resources.items():
                    if citations and entry['Type'] == 'AWS::SecretsManager::RotationSchedule':
                        result['hallazgos'].append({'recurso_logico_id': name, 'control_id': 'SEC-ROTACION', 'estado': 'alerta',
                            'rutas_evidencia': ['/Transform', f'/Resources/{name}/Properties/HostedRotationLambda'],
                            'fragmento_ids': citations, 'justificacion': 'AWS recomienda actualizar el transform de rotación alojada.',
                            'recomendacion': 'Revisar la migración a AWS::SecretsManager-2024-09-16.'})
        return {'texto': encode(result).decode('utf-8'), 'stop_reason': 'end_turn'}


def preflight(root, model):
    folder = root / 'preflight'
    ledger = lambda row: append_event(folder / 'calls.jsonl', row)
    result = model.embed('AWS CloudFormation security group ingress', ledger, 'prueba_embedding')
    vector(result, model.config['dimensions'])
    checks = (
        ('detector', DETECTOR, {'controles': {}, 'plantilla_original': '{"Resources":{}}', 'fragmentos': []}, 'hallazgos'),
        ('informe', REPORT, {'hallazgos': [], 'fragmentos': []}, 'items'),
    )
    for stage, schema, payload, expected in checks:
        prompt = (root / 'config' / (stage + '.txt')).read_text(encoding='utf-8')
        response = model.generate(prompt, payload, schema, stage, ledger)
        if parse_response(response, schema)[expected] != []:
            raise ValueError(f'El modelo debe devolver una lista vacía en la prueba de {stage}.')
    summary = {'fecha': utc(), 'modelos': [model.config['embedding_model'], model.config['text_model']],
               'region': model.config['region'], 'simulacion': isinstance(model, Simulation),
               'dimension': len(result), 'esquemas_compilados': ['detector', 'informe']}
    save_json(folder / ('simulacion.json' if summary['simulacion'] else 'bedrock.json'), summary)
    return summary


def metric_series(values):
    present = [value for value in values if value is not None]
    return {'mediana': statistics.median(present), 'min': min(present), 'max': max(present)} if present else None


def formal_summary(root, prefix):
    runs = [root / 'runs' / f'{prefix}-r{i}' for i in range(1, 4)]
    metrics = [read_json(run / 'metricas.json') for run in runs]
    manifests = [read_json(run / 'manifiesto.json') for run in runs]
    if len({row['sha256'] for row in manifests}) != 1 or any(row['fase'] != 'formal' for row in metrics):
        raise ValueError('Las tres corridas deben compartir el mismo protocolo formal')
    if any(row['completas'] != 10 for row in metrics):
        raise ValueError('La síntesis requiere las diez plantillas puntuadas en cada corrida')
    historical = {'TP': 17, 'FP': 3, 'FN': 3, 'precision': .85, 'recall': .85, 'f1': .85,
                  'recuperacion_s': 2.07, 'detector_s': 70, 'informe_s': 13, 'total_s': 85.1}
    stat_keys = ['TP', 'FP', 'FN', 'duplicado', 'precision', 'recall', 'f1', 'fraccion_alertas_incorrectas']
    stat = {key: metric_series([row['micro'][key] for row in metrics]) for key in stat_keys}
    result = {'simulacion': metrics[0]['simulacion'], 'original_Toprani_Madisetti': historical,
              'replica': stat, 'corridas': [run.name for run in runs],
              'latencia_s_media_por_corrida': [row['latencia_s'] for row in metrics]}
    save_json(root / 'runs' / f'{prefix}-resumen.json', result)
    heading = '## Prueba con respuestas simuladas' if result['simulacion'] else '## Resultados de la réplica'
    lines = ['# Comparación formal', '', heading, '',
             '| Métrica | Referencia histórica | Mediana | Rango |', '|---|---:|---:|---:|']
    for label in stat_keys:
        baseline = historical.get(label)
        values = stat[label]
        spread = f'{display_score(values["min"])} a {display_score(values["max"])}' if values else 'N/A'
        lines.append(f'| {label} | {display_score(baseline)} | {display_score(values["mediana"] if values else None)} | {spread} |')
    lines.extend(['', '## Latencia media por corrida', '', '| Corrida | Recuperación s | Detector s | Informe s | Total comparable s |', '|---|---:|---:|---:|---:|'])
    lines.append('| Paper | 2.07 | 70.00 | 13.00 | 85.10 |')
    for run, row in zip(runs, metrics):
        values = [f'{row["latencia_s"][stage]["media"]:.2f}' for stage in ('recuperacion', 'detector', 'informe', 'total_comparable')]
        lines.append('| ' + ' | '.join([run.name, *values]) + ' |')
    lines.extend(['', 'La comparación es histórica. El estudio usa plantillas sustitutas, Sonnet 4.6 y un índice NumPy.',
                  '', '[Tablas 1 y 2 del artículo](https://ieeexplore.ieee.org/document/10965635)', ''])
    save(root / 'runs' / f'{prefix}-resumen.md', '\n'.join(lines))
    return result


def update_summary(root, prefix):
    report = []
    identities = set()
    for number in range(1, 4):
        for version in ('base', 'actualizada'):
            run = root / 'runs' / f'{prefix}-r{number}-{version}'
            manifest = read_json(run / 'manifiesto.json')
            if manifest['fase'] != 'actualizacion' or manifest['version_docs'] != version:
                raise ValueError('El manifiesto no coincide con el diseño pareado')
            identities.add(digest(encode([manifest['identidad'], manifest['simulacion'], manifest['dependencias']])))
            for item in read_json(run / 'progreso.json'):
                case = item['plantilla_id']
                if item['estado'] != 'completa':
                    report.append({'par': number, 'base': version, 'plantilla_id': case, 'estado': 'incompleta'})
                    continue
                passages = read_json(run / case / 'recuperacion.json')['fragmentos']
                matches = [alert for alert in read_json(run / case / 'hallazgos.json') if alert['estado'] == 'alerta'
                           and alert['control_id'] == 'SEC-ROTACION']
                report.append({'par': number, 'base': version, 'plantilla_id': case, 'estado': 'completa',
                    'simulacion': manifest['simulacion'],
                    'aviso_recuperado': any(p['fragmento_id'].startswith('AVISO-') for p in passages),
                    'aviso_citado': any(ref.startswith('AVISO-') and ref not in alert['fragmentos_invalidos']
                                       for alert in matches for ref in alert['fragmento_ids']),
                    'alertas_migracion': len(matches), 'recomendaciones_detector': [alert['recomendacion'] for alert in matches],
                    'ruta_informe': str(run.relative_to(root) / case / 'informe.md'), 'revision_especialista': ''})
    if len(identities) != 1:
        raise ValueError('Los pares deben mantener las mismas entradas, modelo y configuración')
    output = root / 'runs' / f'{prefix}-comparacion.csv'
    prior = {(row['par'], row['base'], row['plantilla_id']): row['revision_especialista'] for row in read_csv(output)} if output.exists() else {}
    for row in report:
        row['revision_especialista'] = prior.get((str(row['par']), row['base'], row['plantilla_id']), '')
    save_csv(output, report, ['par', 'base', 'plantilla_id', 'estado', 'simulacion', 'aviso_recuperado',
        'aviso_citado', 'alertas_migracion', 'recomendaciones_detector', 'ruta_informe', 'revision_especialista'])
    return report


def estimate_usage(pilot_run, root=None, rates=None):
    manifest = read_json(pilot_run / 'manifiesto.json')
    if manifest['fase'] != 'piloto' or manifest['simulacion']:
        raise ValueError('La estimación requiere el piloto ejecutado con Bedrock')
    progress = read_json(pilot_run / 'progreso.json')
    if any(row['estado'] != 'completa' for row in progress):
        raise ValueError('Completar los tres casos del piloto antes de proyectar')
    by_stage = {}
    for case in progress:
        path = pilot_run / case['plantilla_id'] / 'calls.jsonl'
        for line in path.read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            usage = row.get('uso', {})
            stats = by_stage.setdefault(row['etapa'], {'llamadas': 0, 'entrada': 0, 'salida': 0, 'modelo': row['modelo'], 'errores': 0})
            stats['llamadas'] += 1
            stats['entrada'] += usage.get('inputTokens', 0)
            stats['salida'] += usage.get('outputTokens', 0)
            stats['errores'] += 'error' in row
    queries_expected = None
    index_calls = None
    num_templates = 42
    if root is not None:
        workload = {}
        for phase, repeats in [('formal', 3), ('actualizacion', 6)]:
            data_root = root / 'corpus' / phase
            cases = suite_cases(root, phase)
            queries = 0
            for case in cases:
                source = data_root / case['archivo']
                data = normalize(source.read_text(encoding='utf-8'), source.suffix, read_json(data_root / case['contexto']))
                queries += len(data['consultas'])
            workload[phase] = (len(cases)*repeats, queries*repeats)
        num_templates = sum(n for n, _ in workload.values())
        queries_expected = sum(n for _, n in workload.values())
        index_calls = len(docs_for_version(root, 'actualizada')) - len(docs_for_version(root, 'base'))
    projected = {}
    for stage, stats in by_stage.items():
        factor = num_templates / len(progress)
        if stage == 'recuperacion' and queries_expected:
            factor = queries_expected / max(stats['llamadas'] - stats['errores'], 1)
        projected[stage] = dict(stats, **{k: round(stats[k]*factor) for k in ('entrada', 'salida', 'llamadas', 'errores')})
    cost = None
    pending = [row['modelo'] for row in projected.values() if not rates or row['modelo'] not in rates]
    if not pending:
        cost = sum((row['entrada']*rates[row['modelo']]['entrada'] + row['salida']*rates[row['modelo']]['salida'])/1_000_000
                   for row in projected.values())
    return {'plantillas_proyectadas': num_templates, 'consultas_embedding_previstas': queries_expected,
            'etapas': projected, 'indexacion_adicional_llamadas': index_calls,
            'usd_inferencia_aproximados_sin_indexacion': cost, 'tarifas_usd_por_millon': rates,
            'observacion': 'La proyección lineal usa plantillas pequeñas. Reservar margen por casos formales más largos.'}
