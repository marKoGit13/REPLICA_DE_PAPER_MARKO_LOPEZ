# Ejecutar la réplica de Toprani y Madisetti

## Primera plantilla

1. Abre `Replica_Toprani_2025.ipynb` en Google Colab y selecciona CPU. Ejecuta las celdas con los valores iniciales para probar la instalación y generar un informe local de S01.
2. En la sección **Secrets** agrega `BEDROCK_API_KEY` con acceso al cuaderno. Usa una clave de Amazon Bedrock temporal que permita `InvokeModel` para Titan V2 en `us-east-1` y el perfil de inferencia de Sonnet 4.6. Los permisos del perfil también pueden depender de las regiones de destino. Consulta el error en `preflight/calls.jsonl` si Bedrock rechaza una llamada. [Claves de Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/api-keys-use.html), [Perfil de Sonnet 4.6](https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-anthropic-claude-sonnet-4-6.html).
3. Cambia `MODO` a `detectar`, deja `FASE` en `smoke` y usa `smoke-bedrock` como ID. Ejecuta todas las celdas. El primer acceso valida ambos modelos y prepara los esquemas de salida. La primera compilación de esquemas puede tardar más que las corridas siguientes. [Salidas estructuradas de Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/structured-output.html).
4. En la carpeta privada del evaluador, coloca `Referencias_Toprani_Evaluador.zip`. Cambia `MODO` a `evaluar` y conserva fase e ID. En `runs/smoke-bedrock/S01/informe_puntuado.md`, el resultado esperado es un acierto, cero alertas incorrectas y cero omisiones. Revisar también que el informe cite documentación recuperada y la ruta real de la regla.

Usa `Codigo_y_corpus_Toprani.zip` si quieres leer o versionar el código fuera de Colab. El notebook contiene el mismo paquete público e instala solo los archivos faltantes de la carpeta del estudio. Para partir de una entrega nueva, usa una nueva carpeta del estudio.

## Piloto, cierre y comparación

- Ejecuta `piloto` con un ID nuevo, por ejemplo `piloto-bedrock`. Revisa los recuentos, evidencias y abstenciones. P01 evalúa el control en una regla HTTP, P02 es una alerta evidente y P03 requiere vincular el grupo con una lista de prefijos local. Ajusta solo con los casos de desarrollo y registra los cambios.
- El evaluador mantiene las etiquetas en su Drive privado. Si usas cuentas separadas, comparte solo la carpeta pública del estudio con permiso de edición para el evaluador y añade un acceso directo a su unidad para poder montarla en Colab. Configura `DIRECTORIO_ESTUDIO` y `DIRECTORIO_EVALUADOR` según la ubicación real.
- El especialista abre `formal/referencia.csv`, revisa la aplicabilidad y el alcance de los cinco controles en todas las plantillas, y completa `revisor` y `fecha_revision`. Las etiquetas provistas son propuestas. Después usa `evaluar`, `formal` y `CONFIRMAR_REVISION_FORMAL` para generar la constancia. La constancia verifica hashes, evidencias y distribución, y carece de etiquetas en texto claro.
- Corre `formal` en `detectar`. Cambia luego a `evaluar` con el mismo prefijo. Se conservan tres repeticiones, la comparación histórica y la rúbrica por corrida. Cada combinación de plantilla, recurso y control aporta como máximo un acierto. Las abstenciones, alertas indeterminadas y duplicados quedan visibles en el archivo de emparejamientos.
- Repite el procedimiento para `actualizacion`. Los dos casos provienen de ejemplos oficiales de DocumentDB. Existen diferencias entre ellos además del transform. Cada YAML se mantiene fijo al comparar las dos instantáneas documentales, un antes y un después por caso. Anota si la recomendación específica fue correcta en `*-comparacion.csv`.
- Para presupuestar, activa `CALCULAR_PRESUPUESTO` con el ID del piloto real. Introduce las tarifas por millón de tokens del perfil y región si quieres un importe en USD. Los tokens del informe y la detección se extrapolan a partir de un piloto pequeño y los vectores de consulta se proyectan con el número de tipos de recurso de las plantillas formales. Reserva margen para documentos y respuestas más extensos. La columna de indexación indica las llamadas adicionales esperadas con la base del piloto en caché. [Precios de Bedrock](https://aws.amazon.com/bedrock/pricing/).

## Decisiones de implementación

- El original recibe la plantilla sin procesar, un resumen y fragmentos recuperados. Esta réplica mantiene esas entradas y sustituye Bedrock Agents por dos llamadas a Converse. AWS marca el perfil público de Claude 3.5 Sonnet v2 como retirado en las regiones norteamericanas listadas. Se elige Sonnet 4.6 para las dos funciones. [Disponibilidad regional](https://docs.aws.amazon.com/bedrock/latest/userguide/models-region-compatibility.html), [Artículo y tablas históricas](https://ieeexplore.ieee.org/document/10965635).
- La base incorpora instantáneas curadas de documentación de AWS en español, con referencias verificables. El PDF íntegro de CIS no está incluido. Para añadir material autorizado, copia las dos instantáneas, incorpora el mismo material a ambas, añade los archivos al manifiesto con su SHA-256 y cierra una nueva variante del protocolo. La base actualizada añade una paráfrasis del anuncio de Secrets Manager de diciembre de 2024. [Benchmark CIS para AWS](https://www.cisecurity.org/benchmark/amazon-web-services), [Anuncio de AWS](https://aws.amazon.com/blogs/security/introducing-an-enhanced-version-of-the-aws-secrets-manager-transform-awssecretsmanager-2024-09-16/).
- Las cinco plantillas formales con incidencias combinan ejemplos de AWS porque los casos públicos individuales cubrían pocos controles a la vez. En los casos que requerían variantes se registraron cambios y motivos. Se usan cinco ejemplos públicos adicionales como controles, dos de ellos con componentes compartidos con casos compuestos. Interpretar las diez plantillas como un corpus pequeño, con casos relacionados. Los nombres de archivo son neutros y el detector recibe el código y contexto, sin la procedencia que contiene la respuesta esperada. [Ejemplos de AWS Control Tower](https://docs.aws.amazon.com/controltower/latest/controlreference/).
- Los ejemplos de código procedentes de `docs.aws.amazon.com` están sujetos a MIT-0 salvo indicación distinta. Las paráfrasis de material AWS tienen enlaces de atribución. [Condiciones de AWS](https://aws.amazon.com/terms/).
- Los informes describen configuraciones declaradas en IaC bajo un escenario explícito. Los detalles de política de cuenta, recursos importados y condiciones sin datos pueden requerir una abstención. La evaluación de recomendaciones es textual.

## Resultados en Drive

| Ruta | Contenido |
|---|---|
| `corpus/<fase>/` | Plantillas, contexto y manifiesto de procedencia |
| `docs/<versión>/` | Pasajes y huellas de las fuentes |
| `indices/` | Vectores persistentes, registro de llamadas e índices por versión |
| `runs/<ID>/<plantilla>/` | Plantilla original, resumen, recuperación, respuestas, hallazgos JSON, informe, estado y consumo |
| `runs/<ID>/` | Manifiesto de corrida, progreso, métricas, emparejamiento y rúbrica |
| `runs/<prefijo>-resumen.*` | Resultado formal agregado y tablas históricas |

Para reanudar usa el mismo ID y la misma configuración. Si una etapa queda incompleta, consulta el error de esa plantilla. Las etapas confirmadas se conservan tras el reinicio. Un cambio al modelo, corpus o documentación requiere otro ID. Los reintentos de errores transitorios se registran en `calls.jsonl`. El cotejo histórico usa el tiempo activo de recuperación, detector e informe. La carga inicial del índice queda fuera de ese total.
