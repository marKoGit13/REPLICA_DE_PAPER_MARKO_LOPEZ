## AWS::S3::Bucket y cifrado por defecto
Desde enero de 2023, S3 cifra automáticamente las nuevas cargas de objetos. El nivel de base es SSE-S3, administrado por S3. Una plantilla sin `BucketEncryption` requiere análisis del requisito operativo antes de afirmar un incumplimiento de KMS. La falta de declaración no acredita que los objetos nuevos se almacenen sin cifrado.
