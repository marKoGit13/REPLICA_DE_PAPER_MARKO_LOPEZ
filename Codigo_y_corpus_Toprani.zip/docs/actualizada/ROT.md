## AWS::SecretsManager::RotationSchedule y rotación alojada
La rotación del secreto puede usar una función Lambda que coordina el cambio con el servicio donde se validan las credenciales. La función requiere permisos adecuados para leer o actualizar su secreto y para comunicarse con el sistema que lo consume. Este pasaje describe el mecanismo general de rotación.
