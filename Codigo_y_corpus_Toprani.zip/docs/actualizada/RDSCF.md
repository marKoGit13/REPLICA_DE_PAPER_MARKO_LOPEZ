## StorageEncrypted y cambios de instancia
En CloudFormation, habilitar `StorageEncrypted` configura el cifrado de almacenamiento para la instancia admitida. Si se configura cifrado sin `KmsKeyId`, CloudFormation puede usar la clave por defecto. En un cambio sobre un recurso existente, revisar las condiciones de reemplazo y el plan de migración antes de proponer una edición directa.
