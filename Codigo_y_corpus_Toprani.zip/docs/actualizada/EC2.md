## AWS::EC2::SecurityGroup y SSH
El control EC2.13 de AWS Security Hub comprueba si un grupo de seguridad admite acceso entrante a TCP/22 desde cualquier dirección IPv4 o IPv6. La evaluación incluye reglas que cubren el puerto dentro de un intervalo. El acceso administrativo debe acotarse al origen autorizado o eliminarse si resulta innecesario.

## AWS::EC2::SecurityGroupIngress en CloudFormation
`SecurityGroupIngress` puede aparecer como lista dentro del grupo o como un recurso independiente. En el segundo caso `GroupId` indica el grupo destino. `IpProtocol: -1` permite todos los protocolos y abarca los puertos TCP, aun sin límites de puerto en la regla. Los orígenes pueden referirse a una lista de prefijos mediante `SourcePrefixListId`. Revisar las entradas de una lista definida en el mismo documento permite interpretar el rango referenciado.
