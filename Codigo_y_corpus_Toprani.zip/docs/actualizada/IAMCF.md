## AWS::IAM::Role Policies ManagedPolicyArns
`Policies` incorpora políticas en línea al rol. `ManagedPolicyArns` referencia políticas administradas. Otros recursos CloudFormation, como `AWS::IAM::Policy` y `AWS::IAM::ManagedPolicy`, permiten asociar políticas a roles usando la propiedad `Roles`. Seguir estas asociaciones antes de comparar lo concedido con el uso permitido.
