# Referencias reservadas

Conserva este archivo en la carpeta privada del evaluador. Las etiquetas son propuestas. Revisa `formal/referencia.csv` y completa `revisor` y `fecha_revision` antes de cerrar la referencia formal. La carpeta `procedencia` explica los cambios de los casos derivados y puede revelar sus etiquetas.
